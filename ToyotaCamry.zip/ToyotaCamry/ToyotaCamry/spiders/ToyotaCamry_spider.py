from scrapy import Spider, Request
from ToyotaCamry.items import ToyotaCamryItem


class ToyotaCamryspider (Spider):
    name = 'ToyotaCamry_spider'
    allowed_urls = ['https://www.edmunds.com/']
    start_urls = ['https://www.edmunds.com/inventory/srp.html?inventorytype=used%2Ccpo&make=toyota&model=camry&radius=6000']

    def parse(self, response):
        N = int(response.xpath('//div[@class="srp-pagination text-center row align-items-center flex-nowrap"]//text()')
                .extract()[-1].replace(',', ''))
        result_urls = ['https://www.edmunds.com/inventory/srp.html?inventorytype=used%2Ccpo&make=toyota&model=camry&pagenumber={}&radius=6000'.format(i)
                       for i in range(1, N+1)]

        for url in result_urls:
            yield Request(url=url, callback=self.parse_each_page)

    def parse_each_page(self, response):
        rows = response.xpath('//li[@data-tracking-id="srp_view_vin_details"]')

        for row in rows:
            Model = ''.join(row.xpath('.//a[@class="d-block h5 mb-0"]/text()')
                            .extract()[6:10])
            Price = row.xpath('.//h3[@class="mb-0 text-gray-darker"]/text()') \
                .extract_first()
            Mileage = row.xpath('.//span[@class="text-gray-darker ml-0_25"]/text()') \
                .extract_first().split()[0]
            Year = row.xpath('.//a[@class="d-block h5 mb-0"]/text()') \
                .extract()[2]

            # Extract color node using XPath,
            # check for tag existence, and then extract inner text.
            colorNode = row.xpath('.//span[@class="color-swatch ml-0_25 d-inline-block align-text-top"]/@aria-label') \
                .extract_first()
            # Fallback: For cars missing Exterior Color attribute,
            # set extracted attribtue to an empty string.
            if colorNode is None:
                Extcolor = ''
            else:
                Extcolor = colorNode.split()[2:5]

            Milerange = row.xpath('.//div[@class="disclaimer text-gray-dark"]/text()') \
                .extract_first().split()[0]

            item = ToyotaCamryItem()
            item['Model'] = Model
            item['Price'] = Price
            item['Mileage'] = Mileage
            item['Year'] = Year
            item['Extcolor'] = Extcolor
            item['Milerange'] = Milerange
            yield item
